# Запуск приложения

Установить правильную `ConnectionString` в `appsettings.json`

В консоли ввести:
`dotnet run --project .\Simbir.GO.WebApi\`

Затем открыть `http://localhost:5142/swagger`

(P.S сделал за ночь, хотел сделать все, но просто не успел, с UserManager разбирался >_< )
