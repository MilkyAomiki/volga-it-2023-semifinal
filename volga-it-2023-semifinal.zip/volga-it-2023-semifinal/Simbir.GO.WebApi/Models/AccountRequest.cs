namespace Simbir.GO.WebApi.Models;

public class AccountRequest
{
    public string Username { get; set; }
    public string Password { get; set; }
}
