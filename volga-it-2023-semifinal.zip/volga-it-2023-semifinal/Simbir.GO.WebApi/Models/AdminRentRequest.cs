namespace Simbir.GO.WebApi.Models;

public class AdminRentRequest
{
    public int Id { get; set; }
    public int TransportId { get; set; }
    public int UserId { get; set; }

    /// <summary>
    /// Minutes/Days
    /// </summary>
    public string PriceType { get; set; }
    public DateTime TimeStart { get; set; }
    public DateTime? TimeEnd { get; set; }
    public double Latitude { get; set; }
    public double Longitude { get; set; }

    public int PriceOfUnit { get; set; }
    public int FinalPrice { get; set; }
}
