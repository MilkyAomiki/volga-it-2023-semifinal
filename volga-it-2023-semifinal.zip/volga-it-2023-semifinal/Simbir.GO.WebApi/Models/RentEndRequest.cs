namespace Simbir.GO.WebApi.Models;

public class RentEndRequest
{
    public int Latitude { get; set; }
    public int Longitude { get; set; }
}
