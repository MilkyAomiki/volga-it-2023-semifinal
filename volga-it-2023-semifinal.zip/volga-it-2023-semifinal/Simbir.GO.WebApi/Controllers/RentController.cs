using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Simbir.GO.BLL;
using Simbir.GO.BLL.Models;
using Simbir.GO.WebApi.Models;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Simbir.GO.WebApi.Controllers;

[Route("api/Rent")]
[ApiController]
public class RentController : ControllerBase
{
    private readonly SimbirGoDbContext _dbContext;
    private readonly UserManager<IdentityUser> _userManager;

    public RentController(SimbirGoDbContext dbContext, UserManager<IdentityUser> _userManager)
    {
        _dbContext = dbContext;
    }

    [HttpGet("Transport")]
    [AllowAnonymous]
    public IActionResult GetAvailableTransport(double lat, double lon, double radius, string type)
    {
        var availableTransport = _dbContext.Transports
            .Where(t => t.CanBeRented && CalculateDistance(lat, lon, t.Latitude, t.Longitude) <= radius);

        if (type is not "All")
        {
            availableTransport = availableTransport.Where(t => t.TransportType == type);
        }

        return Ok(availableTransport);
    }

    [HttpGet("{rentId}")]
    [Authorize]
    public async Task<IActionResult> GetRentById(long rentId)
    {
        var rent = await _dbContext.Rents
            .Include(r => r.Transport)
            .Include(r => r.Renter)
            .FirstOrDefaultAsync(r => r.Id == rentId);

        if (rent == null)
        {
            return NotFound();
        }

        return Ok(rent);
    }

    [HttpGet("MyHistory")]
    [Authorize]
    public IActionResult GetMyRentHistory()
    {
        var currentUserId = _userManager.FindByNameAsync(User.Identity.Name).Id; // Get the current user's ID.

        var rentHistory = _dbContext.Rents
            .Include(r => r.Transport)
            .Where(r => r.Renter.Id == currentUserId || r.Transport.Owner.Id == currentUserId)
            .ToList();

        return Ok(rentHistory);
    }

    [HttpGet("TransportHistory/{transportId}")]
    [Authorize]
    public async Task<IActionResult> GetTransportRentHistory(long transportId)
    {
        var transport = await _dbContext.Transports
            .Include(t => t.Owner)
            .FirstOrDefaultAsync(t => t.Id == transportId);

        if (transport == null)
        {
            return NotFound();
        }

        var transportRentHistory = _dbContext.Rents
            .Include(r => r.Renter)
            .Where(r => r.TransportId == transportId)
            .ToList();

        return Ok(transportRentHistory);
    }

    [HttpPost("New/{transportId}")]
    [Authorize]
    public IActionResult StartNewRent(long transportId, [FromBody] string rentType)
    {
        var currentUserId = _userManager.FindByNameAsync(User.Identity.Name).Id; // Get the current user's ID.

        var transport = _dbContext.Transports.Find(transportId);

        if (transport == null || transport.Owner.Id == currentUserId)
        {
            return BadRequest("Invalid transport ID or attempting to rent your own transport.");
        }

        var rent = new Rent
        {
            TransportId = transportId,
            UserId = currentUserId,
            PriceType = rentType,
            StartTime = DateTime.UtcNow,
            EndTime = null,
            Latitude = transport.Latitude,
            Longitude = transport.Longitude
        };

        _dbContext.Rents.Add(rent);
        _dbContext.SaveChanges();

        return Created("", rent);
    }

    [HttpPost("End/{rentId}")]
    [Authorize]
    public IActionResult EndRent(long rentId, [FromBody] RentEndRequest model)
    {
        var rent = _dbContext.Rents.Find(rentId);

        if (rent == null)
        {
            return NotFound();
        }

        var currentUserId = _userManager.FindByNameAsync(User.Identity.Name).Id; // Get the current user's ID.

        if (rent.UserId != currentUserId)
        {
            return BadRequest("You are not authorized to end this rent.");
        }

        rent.EndTime = DateTime.UtcNow;
        rent.Latitude = model.Latitude;
        rent.Longitude = model.Longitude;

        _dbContext.SaveChanges();

        return Ok("Rent ended successfully");
    }

    private double CalculateDistance(double lat1, double lon1, double lat2, double lon2)
    {
        // The radius of the Earth in kilometers
        const double earthRadius = 6371;

        // Convert latitude and longitude from degrees to radians
        double lat1Rad = Math.PI * lat1 / 180.0;
        double lon1Rad = Math.PI * lon1 / 180.0;
        double lat2Rad = Math.PI * lat2 / 180.0;
        double lon2Rad = Math.PI * lon2 / 180.0;
        
        double distance = Math.Acos(Math.Sin(lat1Rad)*Math.Sin(lat2Rad)+Math.Cos(lat1Rad)*Math.Cos(lat2Rad)*Math.Cos(lon2Rad-lon1Rad))* earthRadius;

        return distance;
    }
}
