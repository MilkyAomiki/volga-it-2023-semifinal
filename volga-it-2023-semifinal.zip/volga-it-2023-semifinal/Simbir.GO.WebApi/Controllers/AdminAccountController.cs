using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Simbir.GO.BLL;
using Simbir.GO.BLL.Models;
using Simbir.GO.WebApi.Models;

namespace Simbir.GO.WebApi.Controllers;

[Route("api/Admin/Account")]
[ApiController]
public class AdminAccountController : ControllerBase
{
    private readonly UserManager<IdentityUser> _userManager;
    private readonly SimbirGoDbContext _dbContext;

    public AdminAccountController(UserManager<IdentityUser> userManager, SimbirGoDbContext dbContext)
    {
        _userManager = userManager;
        _dbContext = dbContext;
    }

    [HttpGet]
    [Authorize(Roles = "admin")]
    public async Task<IActionResult> GetAccounts(int start, int count)
    {
        var accounts = _userManager.Users.Skip(start).Take(count).ToList();
        var users = _dbContext.Users.ToList();

        List<object> resultAccounts = new(accounts.Count());
        foreach (var user in users)
        {
            var account = await _userManager.FindByIdAsync(user.AccountId);
            
            resultAccounts.Add(new { user, account, roles = await _userManager.GetRolesAsync(account)});
        }

        return Ok(resultAccounts);
    }

    [HttpGet("{id}")]
    [Authorize(Roles = "admin")]
    public async Task<IActionResult> GetAccountById(long id)
    {
        var user = await _dbContext.Users.FindAsync(id);
        if (user is null)
        {
            return NotFound();
        }

        var account = await _userManager.FindByIdAsync(user.AccountId);

        return Ok(new { user, account = account, roles = await _userManager.GetRolesAsync(account)});
    }

    [HttpPost]
    [Authorize(Roles = "admin")]
    public async Task<IActionResult> CreateAccount([FromBody] AccountRequest model)
    {
        var existingUser = await _userManager.FindByNameAsync(model.Username);
        if (existingUser is not null)
        {
            return Conflict("Username already exists");
        }

        IdentityUser user = new()
        {
            UserName = model.Username
        };
        user.PasswordHash = _userManager.PasswordHasher.HashPassword(user, model.Password);
        var result = await _userManager.CreateAsync(user);

        if (result.Succeeded)
        {
            // if (model.IsAdmin)
            // {
            //     await _userManager.AddToRoleAsync(newUser, "Admin");
            // }

            var currentUser = await _userManager.FindByNameAsync(model.Username);
            _dbContext.Users.Add(
                new User
                {
                    AccountId = currentUser.Id
                }
            );

            return Created("", user);
        }

        return BadRequest(result.Errors);
    }

    [HttpPut("{id}")]
    [Authorize(Roles = "admin")]
    public async Task<IActionResult> UpdateAccount(long id, [FromBody] AccountRequest model)
    {
        var user = _dbContext.Users.Find(id);
        if (user == null)
        {
            return NotFound();
        }

        var account = await _userManager.FindByIdAsync(user.AccountId);

        if (account.UserName != model.Username)
        {
            var existingUser = await _userManager.FindByNameAsync(model.Username);
            if (existingUser != null)
            {
                return Conflict("Username already exists");
            }
        }

        account.UserName = model.Username;
        account.PasswordHash = _userManager.PasswordHasher.HashPassword(account, model.Password);

        var result = await _userManager.UpdateAsync(account);
        if (result.Succeeded)
        {
            return Ok(user);
        }

        return BadRequest(result.Errors);
    }

    [HttpDelete("{id}")]
    [Authorize(Roles = "admin")]
    public async Task<IActionResult> DeleteAccount(long id)
    {
        var user = _dbContext.Users.Find(id);
        if (user == null)
        {
            return NotFound();
        }

        var account = await _userManager.FindByIdAsync(user.AccountId);

        var result = await _userManager.DeleteAsync(account);
        if (result.Succeeded)
        {
            _dbContext.Users.Remove(user);
            _dbContext.SaveChanges();
            return NoContent();
        }

        return BadRequest(result.Errors);
    }
}
