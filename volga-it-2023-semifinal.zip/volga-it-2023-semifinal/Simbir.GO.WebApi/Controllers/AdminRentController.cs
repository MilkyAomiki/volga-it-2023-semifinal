using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Simbir.GO.BLL;
using Simbir.GO.BLL.Models;
using Simbir.GO.WebApi.Models;

namespace Simbir.GO.WebApi.Controllers;

[Route("api/Admin/Rent")]
[ApiController]
[Authorize(Roles = "Admin")]
public class AdminRentController : ControllerBase
{
    private readonly SimbirGoDbContext _dbContext;

    public AdminRentController(SimbirGoDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    [HttpGet("{rentId}")]
    public async Task<IActionResult> GetRentById(long rentId)
    {
        var rent = await _dbContext.Rents.FindAsync(rentId);

        if (rent == null)
        {
            return NotFound();
        }

        return Ok(rent);
    }

    [HttpGet("UserHistory/{userId}")]
    public IActionResult GetUserRentHistory(long userId)
    {
        var userRentHistory = _dbContext.Rents
            .Where(r => r.UserId == userId)
            .ToList();

        return Ok(userRentHistory);
    }

    [HttpGet("TransportHistory/{transportId}")]
    public IActionResult GetTransportRentHistory(long transportId)
    {
        var transportRentHistory = _dbContext.Rents
            .Where(r => r.TransportId == transportId)
            .ToList();

        return Ok(transportRentHistory);
    }

    [HttpPost]
    public IActionResult CreateRent([FromBody] AdminRentRequest model)
    {
        var rent = new Rent
        {
            TransportId = model.TransportId,
            UserId = model.UserId,
            PriceType = model.PriceType,
            StartTime = model.TimeStart,
            EndTime = model.TimeEnd,
            Latitude = model.Latitude,
            Longitude = model.Longitude,
            PriceOfUnit = model.PriceOfUnit,
            FinalPrice = model.FinalPrice,
        };

        _dbContext.Rents.Add(rent);
        _dbContext.SaveChanges();

        return Created("", rent);
    }

    [HttpPost("End/{rentId}")]
    public IActionResult EndRent(long rentId, [FromBody] RentEndRequest model)
    {
        var rent = _dbContext.Rents.Find(rentId);

        if (rent == null)
        {
            return NotFound();
        }

        rent.EndTime = DateTime.UtcNow;
        rent.Latitude = model.Latitude;
        rent.Longitude = model.Longitude;

        _dbContext.SaveChanges();

        return Ok("Rent ended successfully");
    }

    [HttpPut("{id}")]
    public IActionResult UpdateRent(long id, [FromBody] AdminRentRequest model)
    {
        // Implement logic to update a rent as an admin.
        // Return the updated rent details.

        var rent = _dbContext.Rents.Find(id);

        if (rent == null)
        {
            return NotFound();
        }

        rent.TransportId = model.TransportId;
        rent.UserId = model.UserId;
        rent.PriceType = model.PriceType;
        rent.StartTime = model.TimeStart;
        rent.EndTime = model.TimeEnd;
        rent.Latitude = model.Latitude;
        rent.Longitude = model.Longitude;
        rent.PriceOfUnit = model.PriceOfUnit;
        rent.FinalPrice = model.FinalPrice;

        _dbContext.SaveChanges();

        return Ok(rent);
    }

    [HttpDelete("{rentId}")]
    public IActionResult DeleteRent(long rentId)
    {
        var rent = _dbContext.Rents.Find(rentId);

        if (rent == null)
        {
            return NotFound();
        }

        _dbContext.Rents.Remove(rent);
        _dbContext.SaveChanges();

        return NoContent();
    }
}
