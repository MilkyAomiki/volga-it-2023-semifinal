using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Simbir.GO.BLL;

namespace Simbir.GO.WebApi.Controllers;

[Route("api/Payment")]
[ApiController]
public class PaymentController : ControllerBase
{
    private readonly UserManager<IdentityUser> _userManager;
    private readonly SimbirGoDbContext _dbContext;

    public PaymentController(UserManager<IdentityUser> userManager, SimbirGoDbContext dbContext)
    {
        _userManager = userManager;
        _dbContext = dbContext;
    }

    [HttpGet("{accountId}")]
    [Authorize(Roles = "admin")]
    public async Task<IActionResult> AddMoney([FromQuery] long accountId)
    {
        const double cashAmount = 250_000;
        var user = await _dbContext.Users.FindAsync(accountId);

        if (User.IsInRole("admin"))
        {
            user.Cash += cashAmount;
        }
        else
        {
            var currentUser = await _userManager.FindByNameAsync(User.Identity.Name);
            if (user.AccountId != currentUser.Id)
            {
                return Unauthorized();
            }

            user.Cash += cashAmount;
        }

        await _dbContext.SaveChangesAsync();

        return Ok();
    }

}