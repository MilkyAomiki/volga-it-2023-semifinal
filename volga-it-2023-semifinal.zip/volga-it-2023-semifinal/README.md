# Запуск приложения

Установить правильную `ConnectionString` в `appsettings.json`

В консоли ввести:
`dotnet run --project .\Simbir.GO.WebApi\`

Затем открыть `http://localhost:5142/swagger`