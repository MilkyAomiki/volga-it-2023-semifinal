using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Simbir.GO.BLL.Models;

namespace Simbir.GO.BLL;

public class SimbirGoDbContext : IdentityDbContext
{
    public SimbirGoDbContext(DbContextOptions<SimbirGoDbContext> options) : base(options)
    {
    }

    public DbSet<Transport> Transports { get; set; }
    public DbSet<Rent> Rents { get; set; }
    public DbSet<User> Users { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<Transport>(entity =>
        {
            entity.HasKey(t => t.Id);
            entity.Property(t => t.CanBeRented).IsRequired();
            entity.Property(t => t.TransportType).IsRequired();
            entity.Property(t => t.Model).IsRequired();
            entity.Property(t => t.Color).IsRequired();
            entity.Property(t => t.Identifier).IsRequired();
            entity.Property(t => t.Description);
            entity.Property(t => t.Latitude).IsRequired();
            entity.Property(t => t.Longitude).IsRequired();
            entity.Property(t => t.MinutePrice);
            entity.Property(t => t.DayPrice);
            entity.HasOne(t => t.Owner).WithMany().HasForeignKey(t => t.OwnerId);
        });

        modelBuilder.Entity<Rent>(entity =>
        {
            entity.HasKey(r => r.Id);
            entity.Property(r => r.TransportId).IsRequired();
            entity.HasOne(r => r.Transport).WithMany().HasForeignKey(r => r.TransportId);
            entity.Property(r => r.UserId).IsRequired();
            entity.HasOne(r => r.Renter).WithMany().HasForeignKey(r => r.UserId);
            entity.Property(r => r.PriceType).IsRequired();
            entity.Property(r => r.StartTime).IsRequired();
            entity.Property(r => r.EndTime);
            entity.Property(r => r.Latitude).IsRequired();
            entity.Property(r => r.Longitude).IsRequired();
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(r => r.Id);
            entity.Property(r => r.AccountId).IsRequired();
            entity.Property(r => r.Cash).IsRequired();
        });
    }
}

