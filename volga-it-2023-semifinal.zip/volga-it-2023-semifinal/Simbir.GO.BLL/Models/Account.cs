namespace Simbir.GO.BLL.Models;

public class User
{
    public long Id { get; set;}
    public string AccountId { get; set; }
    public double Cash { get; set; } = 0;
}