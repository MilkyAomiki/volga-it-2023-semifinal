namespace Simbir.GO.BLL.Models;

public class Rent
{
    public long Id { get; set; }
    public long TransportId { get; set; }
    public Transport Transport { get; set; }
    public long UserId { get; set; }
    public User Renter { get; set; }

    /// <summary>
    /// Minutes/Days
    /// </summary>
    public string PriceType { get; set; }
    public DateTime StartTime { get; set; }
    public DateTime? EndTime { get; set; }
    public double Latitude { get; set; }
    public double Longitude { get; set; }

    public int PriceOfUnit { get; set; }
    public int FinalPrice { get; set; }
}
